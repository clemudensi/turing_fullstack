(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 9);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

const express = __webpack_require__(5);

const router = express.Router();
module.exports = router;

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

const Sequelize = __webpack_require__(6);

const mysql2 = __webpack_require__(21);

const ProductModel = __webpack_require__(22);

const DepartmentModel = __webpack_require__(23);

const CategoryModel = __webpack_require__(24);

const AttributeModel = __webpack_require__(25);

const CustomerModel = __webpack_require__(26);

const ProductCategoryModel = __webpack_require__(27);

const AttributeValueModel = __webpack_require__(28);

const ProductAttributeModel = __webpack_require__(29);

const ProductReviewModel = __webpack_require__(30);

const ReviewModel = __webpack_require__(31);

const OrderModel = __webpack_require__(32);

const ShoppingCartModel = __webpack_require__(33);

const ShippingModel = __webpack_require__(34);

const ShippingRegionModel = __webpack_require__(35);

const ProductRequestModel = __webpack_require__(36);

const TaxModel = __webpack_require__(37);

const sequelize = new Sequelize(process.env.DB_DATABASE, process.env.DB_USER, process.env.DB_PASSWORD, {
  dialect: 'mysql',
  dialectModule: mysql2,
  host: process.env.DB_HOST,
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  },
  define: {
    timestamps: false,
    freezeTableName: true,
    underscored: true
  },
  dialectOptions: {
    decimalNumbers: true
  }
});
/* Import models*/

const Product = ProductModel(sequelize, Sequelize);
const Department = DepartmentModel(sequelize, Sequelize);
const Category = CategoryModel(sequelize, Sequelize);
const Attribute = AttributeModel(sequelize, Sequelize);
const Customer = CustomerModel(sequelize, Sequelize);
const AttributeValue = AttributeValueModel(sequelize, Sequelize);
const ProductCategory = ProductCategoryModel(sequelize, Sequelize);
const ProductAttribute = ProductAttributeModel(sequelize, Sequelize);
const ProductReview = ProductReviewModel(sequelize, Sequelize);
const Review = ReviewModel(sequelize, Sequelize);
const Order = OrderModel(sequelize, Sequelize);
const ShoppingCart = ShoppingCartModel(sequelize, Sequelize);
const Shipping = ShippingModel(sequelize, Sequelize);
const ShippingRegion = ShippingRegionModel(sequelize, Sequelize);
const ProductRequest = ProductRequestModel(sequelize, Sequelize);
const Tax = TaxModel(sequelize, Sequelize);
const Models = {
  Product,
  Department,
  Attribute,
  Customer,
  Category,
  AttributeValue,
  ProductCategory,
  ProductAttribute,
  ProductRequest,
  Review,
  Order,
  ShoppingCart,
  Shipping,
  ShippingRegion,
  ProductReview,
  Tax
};
const connection = {};
/* Create associations between tables */

Product.belongsToMany(Category, {
  through: 'product_category',
  foreignKey: 'product_id'
});
Product.belongsToMany(AttributeValue, {
  through: 'product_attribute',
  foreignKey: 'product_id'
});
Category.belongsToMany(Product, {
  through: 'product_category',
  foreignKey: 'category_id'
});
AttributeValue.belongsToMany(Product, {
  through: 'product_attribute',
  foreignKey: 'attribute_value_id'
});
/* Create database connection*/

module.exports.connectToDatabase = async () => {
  if (connection.isConnected) {
    console.log('=> Using existing connection.');
    return Models;
  }

  const syncDB = await sequelize.sync();
  setTimeout(() => syncDB, 3600);
  await sequelize.authenticate();
  connection.isConnected = true;
  console.log('=> Created a new connection.');
  return Models;
};

module.exports.sequelize = sequelize;

/***/ }),
/* 2 */
/***/ (function(module, exports) {

const procedures = {
  category_procedure: 'CALL catalog_assign_product_to_category(:inProductId, :inCategoryId)',
  attribute_value_procedure: 'CALL catalog_assign_attribute_value_to_product(:inProductId, :inAttributeValueId)',
  product_attributes_procedure: 'CALL catalog_get_product_attributes(:inProductId)',
  product_category_procedure: 'CALL catalog_get_products_in_category(:inCategoryId, :inStartItem, :inProductsPerPage, :inShortProductDescriptionLength)',
  product_department_procedure: 'CALL catalog_get_products_on_department(:inDepartmentId, :inStartItem, :inProductsPerPage, :inShortProductDescriptionLength)',
  product_location_procedure: 'CALL catalog_get_product_locations(:inProductId)',
  product_review_procedure: 'CALL catalog_get_product_reviews(:inProductId)',

  /** Shopping Cart Procedure*/
  shopping_cart_add_procedure: 'CALL shopping_cart_add_product(:inCartId, :inProductId, :inAttributes)',
  shopping_cart_list_procedure: 'CALL shopping_cart_get_products(:inCartId)',
  shopping_cart_empty_procedure: 'CALL shopping_cart_empty(:inCartId)',
  shopping_cart_move_procedure: 'CALL shopping_cart_move_product_to_cart(:inItemId)',
  shopping_cart_total_procedure: 'CALL shopping_cart_get_total_amount(:inCartId)',
  shopping_cart_save_procedure: 'CALL shopping_cart_save_product_for_later(:inItemId)',
  shopping_cart_get_procedure: 'CALL shopping_cart_get_saved_products(:inCartId)',
  shopping_cart_update_procedure: 'CALL shopping_cart_update(:inItemId, :inQuantity)',
  shopping_cart_remove_procedure: 'CALL shopping_cart_remove_product(:inItemId)',

  /** Customer Procedures*/
  customer_add_procedure: 'CALL customer_add(:inName, :inEmail, :inPassword)',
  customer_get_procedure: 'CALL customer_get_customer(:inCustomerId)',
  customer_get_list_procedure: 'CALL customer_get_customers_list',
  customer_get_shipping_regions_procedure: 'CALL customer_get_shipping_regions',
  customer_update_account_procedure: 'CALL customer_update_account(:inCustomerId, :inName, :inEmail, :inPassword, :inDayPhone, :inEvePhone, :inMobPhone)',
  customer_update_address_procedure: 'CALL customer_update_address(:inCustomerId, :inAddress1, :inAddress2, :inCity, :inRegion, :inPostalCode, :inCountry, :inShippingRegionId)',
  customer_update_credit_card_procedure: 'CALL customer_update_credit_card(:inCustomerId, :inCreditCard)'
};
module.exports = procedures;

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

const jwt = __webpack_require__(7);

const verify_token = (req, res, next) => {
  const bearerHeader = req.headers['authorization'];

  if (typeof bearerHeader !== 'undefined') {
    const bearer = bearerHeader.split(' ');
    req.token = bearer[1];
    next();
  } else {
    res.sendStatus(403);
  }
};

const secure = (req, res, action) => jwt.verify(req.token, process.env.privateKey, (err, data) => {
  if (err) {
    res.status(401).json({
      msg: 'You are unauthorized to perform this operation'
    });
  } else {
    return action();
  }
});

const secureRoute = (req, res) => action => secure(req, res, action);

module.exports = {
  verify_token,
  secureRoute
};

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

/** Confirm User on cognito
* @params {string} username                   - user email address
* @params {string} confirm_code               - AWS signUp confirmation code
*/
const express = __webpack_require__(5);

const cognitoAction = express.Router();

const AmazonCognitoIdentity = __webpack_require__(47);

global.fetch = __webpack_require__(48);

module.exports.cognitoAuthConfig = req => {
  /* AWS pool data */
  const poolData = {
    UserPoolId: process.env.UserPoolId,
    ClientId: process.env.ClientId
  };
  const userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
  const userData = {
    Username: req.email,
    Pool: userPool
  };
  /* Cognito main function for accessing authentication methods */

  const cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
  /* Auth data - username and password */

  const authenticationData = {
    Username: req.username,
    Password: req.password
  };
  const authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails(authenticationData);
  return {
    userPool,
    cognitoUser,
    authenticationDetails
  };
};

module.exports.AmazonCognitoIdentity = AmazonCognitoIdentity;
module.exports.cognitoAction = cognitoAction;

/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = require("express");

/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = require("sequelize");

/***/ }),
/* 7 */
/***/ (function(module, exports) {

module.exports = require("jsonwebtoken");

/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports = require("lodash");

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

const sls = __webpack_require__(10);

const app = __webpack_require__(11);

module.exports.run = sls(app);

/***/ }),
/* 10 */
/***/ (function(module, exports) {

module.exports = require("serverless-http");

/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

const express = __webpack_require__(5);

const logger = __webpack_require__(12);

const app = express();

const bodyParser = __webpack_require__(13);

const fileUpload = __webpack_require__(14);

app.use(fileUpload());
app.use(bodyParser.json());
app.use(logger('dev'));
app.use(bodyParser.urlencoded({
  extended: true
}));

const compression = __webpack_require__(15);

const cors = __webpack_require__(16);

const corsOption = {
  origin: '*',
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
  credentials: true,
  exposedHeaders: ['USER-KEY']
};
app.use(cors(corsOption));

const helmet = __webpack_require__(17);

app.use(helmet());
app.use(compression());

const routes = __webpack_require__(18);

app.use('/api', routes);
module.exports = app;

/***/ }),
/* 12 */
/***/ (function(module, exports) {

module.exports = require("morgan");

/***/ }),
/* 13 */
/***/ (function(module, exports) {

module.exports = require("body-parser");

/***/ }),
/* 14 */
/***/ (function(module, exports) {

module.exports = require("express-fileupload");

/***/ }),
/* 15 */
/***/ (function(module, exports) {

module.exports = require("compression");

/***/ }),
/* 16 */
/***/ (function(module, exports) {

module.exports = require("cors");

/***/ }),
/* 17 */
/***/ (function(module, exports) {

module.exports = require("helmet");

/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

/** All routes */
const Router = __webpack_require__(0);

const products = __webpack_require__(19);

const auth = __webpack_require__(45);

const department = __webpack_require__(52);

const category = __webpack_require__(53);

const attributes = __webpack_require__(54);

const orders = __webpack_require__(56);

const shipping = __webpack_require__(57);

const shopping_cart = __webpack_require__(58);

const tax = __webpack_require__(61);

const customer = __webpack_require__(62);

Router.use(...products, ...auth, department, category, attributes, orders, shipping, shopping_cart, tax, customer);
module.exports = Router;

/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

const user_products = __webpack_require__(20);

const admin_products = __webpack_require__(44);

module.exports = [user_products, admin_products];

/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

/** T-shirt shop product API
 * @params {string} name                  - Product name
 * @params {string} description           - Product description
 * @params {number} price                 - Product price
 * @params {number} discounted_price      - Product discount price
 * @params {string} image                 - Product Front image
 * @params {string} image_2               - Product back image
 * @params {string} thumbnail             - Product thumbnail
 * @params {number} display               - Product display
 * @params {number} product_id            - product ID
 * @params {number} limit                 - Number of row to return
 * @params {array} order                  - row order options
 * @params {object} where                 - query option
 * @params {Model} Product                - Product Model
 * @params {Model} ProductCategory        - Product Model
 * @params {Model} ProductAttribute       - Product Model
 */
const Sequelize = __webpack_require__(6);

const {
  connectToDatabase,
  sequelize
} = __webpack_require__(1);

const productAssociation = __webpack_require__(38);

const product_category_procedure = __webpack_require__(39);

const product_department_procedure = __webpack_require__(40);

const product_location_procedure = __webpack_require__(41);

const product_review_procedure = __webpack_require__(42);

const deleteAssociation = __webpack_require__(43);

const Router = __webpack_require__(0); // const passport = require('passport');


const verifyToken = __webpack_require__(3).verify_token;

const secureRoute = __webpack_require__(3).secureRoute;

const {
  category_procedure,
  attribute_value_procedure
} = __webpack_require__(2);

const Op = Sequelize.Op;
/** Create new product */

Router.post('/v1/product', verifyToken, (req, res) => {
  const product = req.body;
  const {
    categories,
    attributes
  } = req.body;

  try {
    const buildRoute = secureRoute(req, res);
    return buildRoute(async () => {
      const {
        Product
      } = await connectToDatabase();
      /*Create a product*/

      const {
        product_id
      } = await Product.create(product);
      /* assign product category and attribute value to product */

      await productAssociation(sequelize, categories, attributes, product_id, category_procedure, attribute_value_procedure);
      /*GET product with associations*/

      const productItem = await Product.findOne({
        where: {
          product_id
        },
        include: [{
          all: true
        }]
      });
      res.status(201).send({
        success: true,
        msg: 'Successfully created a product',
        productItem
      });
    });
  } catch (err) {
    res.send(err);
  }
});
/**
 * GET all products with limit of 20 items returned per page
 * @params {page}                   - query string
 * @params {category}               - query string
 * */

Router.get('/v1/products', async (req, res) => {
  const {
    page,
    category
  } = req.query;

  try {
    const {
      Product,
      Category,
      AttributeValue
    } = await connectToDatabase();
    const products = await Product.findAll({
      limit: 20,
      offset: 20 * (page - 1),
      include: [{
        model: Category,
        attributes: {
          exclude: ['product_category']
        },
        where: {
          name: {
            [Op.regexp]: category
          }
        }
      }, {
        model: AttributeValue,
        attributes: {
          exclude: ['product_attribute']
        }
      }]
    });
    const total = await Product.count({
      include: [{
        model: Category,
        where: {
          name: {
            [Op.regexp]: category
          }
        }
      }]
    });

    if (products.length === 0) {
      res.status(200).send({
        success: true,
        msg: `No product found for page ${page}`
      });
    } else {
      res.status(200).send({
        products,
        total
      });
    }
  } catch (err) {
    res.send(err);
  }
});
/** GET all products */

Router.get('/v1/products/all', async (req, res) => {
  try {
    const {
      Product,
      Category,
      AttributeValue
    } = await connectToDatabase();
    const products = await Product.findAll({
      include: [{
        model: Category,
        attributes: ['name', 'description'],
        through: {
          attributes: []
        }
      }, {
        model: AttributeValue,
        attributes: ['value'],
        through: {
          attributes: []
        }
      }]
    });
    res.status(200).send(products);
  } catch (err) {
    res.send(err);
  }
});
/** GET search for products */

Router.get('/v1/products/search', async (req, res) => {
  const {
    searchQuery
  } = req.query;

  try {
    const {
      Product,
      Category
    } = await connectToDatabase();
    const products = await Product.findAll({
      where: {
        [Op.or]: [{
          name: {
            [Op.like]: '%' + searchQuery + '%'
          }
        }, {
          description: {
            [Op.like]: '%' + searchQuery + '%'
          }
        }]
      },
      include: [{
        model: Category,
        attributes: ['name', 'department_id'],
        through: {
          attributes: []
        }
      }]
    });
    res.status(200).send(products);
  } catch (err) {
    res.send(err);
  }
});
/** GET last product item in a row*/

Router.get('/v1/product/last', async (req, res) => {
  try {
    const {
      Product,
      Category,
      AttributeValue
    } = await connectToDatabase();
    const products = await Product.findAll({
      limit: 1,
      order: [['product_id', 'DESC']],
      include: [{
        model: Category
      }, {
        model: AttributeValue
      }]
    });
    res.status(200).send(products);
  } catch (err) {
    res.send(err);
  }
});
/** GET first 20 hottest product*/

Router.get('/v1/products/hottest', async (req, res) => {
  try {
    const {
      Product,
      Category,
      AttributeValue
    } = await connectToDatabase();
    const products = await Product.findAll({
      limit: 20,
      order: [['likes', 'DESC']],
      include: [{
        model: Category
      }, {
        model: AttributeValue
      }]
    });
    res.status(200).send(products);
  } catch (err) {
    res.send(err);
  }
});
/* GET a product using product id*/

Router.get('/v1/product/:product_id', async (req, res) => {
  const {
    product_id
  } = req.params;

  try {
    const {
      Product,
      Category,
      AttributeValue
    } = await connectToDatabase();
    const product = await Product.findOne({
      where: {
        product_id
      },
      include: [{
        model: Category,
        through: {
          attributes: []
        }
      }, {
        model: AttributeValue,
        through: {
          attributes: []
        }
      }]
    });

    if (!product) {
      res.send({
        status: 404,
        msg: `Product with id: ${product_id} does not exist`
      });
    } else {
      res.status(200).send(product);
    }
  } catch (err) {
    res.send(err);
  }
});
/* GET a product details using product id*/

Router.get('/v1/product/:product_id/details', async (req, res) => {
  const {
    product_id
  } = req.params;

  try {
    const {
      Product
    } = await connectToDatabase();
    const product = await Product.findOne({
      where: {
        product_id
      }
    });

    if (!product) {
      res.send({
        status: 404,
        msg: `Product with id: ${product_id} does not exist`
      });
    } else {
      res.status(200).send(product);
    }
  } catch (err) {
    res.send(err);
  }
});
/* GET a products using category_id*/

Router.get('/v1/products/inCategory/:category_id', async (req, res) => {
  const {
    category_id
  } = req.params;
  const {
    inStartItem,
    inProductsPerPage,
    inShortProductDescriptionLength
  } = req.query;

  try {
    const products = await product_category_procedure(sequelize, category_id, inStartItem, inProductsPerPage, inShortProductDescriptionLength);

    if (!products) {
      res.send({
        status: 404,
        msg: `Product with id: ${category_id} does not exist`
      });
    } else {
      res.status(200).send(products);
    }
  } catch (err) {
    res.send(err);
  }
});
/* GET a products using department_id*/

Router.get('/v1/products/inDepartment/:department_id', async (req, res) => {
  const {
    department_id
  } = req.params;
  const {
    inStartItem,
    inProductsPerPage,
    inShortProductDescriptionLength
  } = req.query;

  try {
    const products = await product_department_procedure(sequelize, department_id, inStartItem, inProductsPerPage, inShortProductDescriptionLength);

    if (!products) {
      res.send({
        status: 404,
        msg: `Product with id: ${department_id} does not exist`
      });
    } else {
      res.status(200).send(products);
    }
  } catch (err) {
    res.send(err);
  }
});
/* GET location of a product */

Router.get('/v1/product/:product_id/locations', async (req, res) => {
  const {
    product_id
  } = req.params;

  try {
    const location = await product_location_procedure(sequelize, product_id);

    if (!location) {
      res.send({
        status: 404,
        msg: `Product with id: ${product_id} does not exist`
      });
    } else {
      res.status(200).send(location);
    }
  } catch (err) {
    res.send(err);
  }
});
/* GET reviews of a product */

Router.get('/v1/product/:product_id/reviews', async (req, res) => {
  const {
    product_id
  } = req.params;

  try {
    const products = await product_review_procedure(sequelize, product_id);

    if (!products) {
      res.send({
        status: 404,
        msg: `Product with id: ${product_id} does not exist`
      });
    } else {
      res.status(200).send(products);
    }
  } catch (err) {
    res.send(err);
  }
});
/* POST reviews of a product */

Router.post('/v1/product/:product_id/reviews', verifyToken, async (req, res) => {
  const product_review = req.body;

  try {
    const buildRoute = secureRoute(req, res);
    return buildRoute(async () => {
      const {
        Review
      } = await connectToDatabase();
      const productReview = await Review.create(product_review);
      res.status(201).send(productReview);
    });
  } catch (err) {
    res.send(err);
  }
});
/* UPDATE exist product using product ID */

Router.put('/v1/product/:product_id', async (req, res) => {
  const {
    product_id
  } = req.params;
  const product = req.body;
  const {
    categories,
    attributes
  } = product;

  try {
    const {
      Product
    } = await connectToDatabase();
    const productItem = await Product.update(product, {
      where: {
        product_id
      }
    });
    /* assign product category and attribute value to  product */

    attributes ? await productAssociation(sequelize, categories, attributes, product_id, category_procedure, attribute_value_procedure) : null;

    if (!product) {
      res.send({
        status: 403,
        msg: `There was an error updating Product with id: ${product_id}`
      });
    } else {
      res.status(202).send({
        success: true,
        msg: 'Successfully updated product',
        productItem
      });
    }
  } catch (err) {
    res.send(err);
  }
});
/* DELETE product and all associations using product ID */

Router.delete('/v1/product/:product_id', async (req, res) => {
  const {
    product_id
  } = req.params;

  try {
    const {
      Product,
      ProductCategory,
      ProductAttribute
    } = await connectToDatabase();
    /* find product form Product model*/

    const productItem = await Product.findOne({
      where: {
        product_id
      }
    });

    if (!productItem) {
      res.send({
        status: 404,
        msg: `Product with id: ${product_id} does not exist`
      });
    } else {
      /* remove product form DB */
      await productItem.destroy();
      await deleteAssociation(ProductCategory, product_id);
      await deleteAssociation(ProductAttribute, product_id);
      res.sendStatus(204);
    }
  } catch (err) {
    res.send(err);
  }
});
module.exports = Router;

/***/ }),
/* 21 */
/***/ (function(module, exports) {

module.exports = require("mysql2");

/***/ }),
/* 22 */
/***/ (function(module, exports) {

module.exports = (sequelize, DataType) => {
  const {
    STRING,
    INTEGER,
    DECIMAL
  } = DataType;
  return sequelize.define('product', {
    product_id: {
      type: INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    name: STRING,
    description: STRING,
    price: DECIMAL,
    discounted_price: DECIMAL,
    image: STRING,
    image_2: STRING,
    thumbnail: STRING,
    likes: {
      type: INTEGER,
      defaultValue: 0
    },
    display: INTEGER
  });
};

/***/ }),
/* 23 */
/***/ (function(module, exports) {

module.exports = (sequelize, DataType) => {
  const {
    STRING,
    INTEGER
  } = DataType;
  return sequelize.define('department', {
    department_id: {
      type: INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    name: STRING,
    description: STRING
  });
};

/***/ }),
/* 24 */
/***/ (function(module, exports) {

module.exports = (sequelize, DataType) => {
  const {
    INTEGER,
    STRING
  } = DataType;
  return sequelize.define('category', {
    category_id: {
      type: INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    department_id: INTEGER,
    name: STRING,
    description: STRING
  });
};

/***/ }),
/* 25 */
/***/ (function(module, exports) {

module.exports = (sequelize, DataType) => {
  const {
    INTEGER,
    STRING
  } = DataType;
  return sequelize.define('attribute', {
    attribute_id: {
      type: INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    name: STRING
  });
};

/***/ }),
/* 26 */
/***/ (function(module, exports) {

module.exports = (sequelize, DataType) => {
  const {
    INTEGER,
    STRING,
    TEXT
  } = DataType;
  return sequelize.define('customer', {
    customer_id: {
      type: INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    password: STRING,
    name: STRING,
    email: STRING,
    credit_card: TEXT,
    address_1: STRING,
    address_2: STRING,
    region: STRING,
    city: STRING,
    postal_code: STRING,
    country: STRING,
    shipping_region_id: INTEGER,
    day_phone: STRING,
    eve_phone: STRING,
    mob_phone: STRING,
    user_type: STRING,
    access_level: INTEGER
  });
};

/***/ }),
/* 27 */
/***/ (function(module, exports) {

module.exports = (sequelize, DataType) => {
  const {
    INTEGER
  } = DataType;
  return sequelize.define('product_category', {
    product_id: {
      type: INTEGER,
      allowNull: false,
      primaryKey: true
    },
    category_id: {
      type: INTEGER,
      allowNull: false,
      primaryKey: true
    }
  });
};

/***/ }),
/* 28 */
/***/ (function(module, exports) {

module.exports = (sequelize, DataType) => {
  const {
    INTEGER,
    STRING
  } = DataType;
  return sequelize.define('attribute_value', {
    attribute_value_id: {
      type: INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    attribute_id: {
      type: INTEGER,
      allowNull: false
    },
    value: {
      type: STRING,
      allowNull: false
    }
  });
};

/***/ }),
/* 29 */
/***/ (function(module, exports) {

module.exports = (sequelize, DataType) => {
  const {
    INTEGER
  } = DataType;
  return sequelize.define('product_attribute', {
    product_id: {
      type: INTEGER,
      primaryKey: true,
      references: {
        model: 'product',
        key: 'product_id'
      }
    },
    attribute_value_id: {
      type: INTEGER,
      primaryKey: true,
      references: {
        model: 'attribute',
        key: 'attribute_value_id'
      }
    }
  });
};

/***/ }),
/* 30 */
/***/ (function(module, exports) {

module.exports = (sequelize, DataType) => {
  const {
    INTEGER
  } = DataType;
  return sequelize.define('product_review', {
    product_id: {
      type: INTEGER,
      allowNull: false,
      primaryKey: true
    },
    category_id: {
      type: INTEGER,
      allowNull: false,
      primaryKey: true
    }
  });
};

/***/ }),
/* 31 */
/***/ (function(module, exports) {

module.exports = (sequelize, DataType) => {
  const {
    INTEGER,
    DATE,
    TEXT
  } = DataType;
  return sequelize.define('review', {
    review_id: {
      type: INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    customer_id: INTEGER,
    product_id: INTEGER,
    review: TEXT,
    rating: INTEGER,
    created_on: {
      type: DATE,
      allowNull: false,
      defaultValue: new Date()
    }
  });
};

/***/ }),
/* 32 */
/***/ (function(module, exports, __webpack_require__) {

const Sequelize = __webpack_require__(6);

module.exports = (sequelize, DataType) => {
  const {
    INTEGER,
    STRING,
    DATE
  } = DataType;
  return sequelize.define('orders', {
    order_id: {
      type: INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    total_amount: INTEGER,
    created_on: {
      type: DATE,
      allowNull: false,
      defaultValue: new Date()
    },
    shipped_on: DATE,
    status: INTEGER,
    comments: STRING,
    customer_id: INTEGER,
    auth_code: STRING,
    reference: STRING,
    shipping_id: INTEGER,
    tax_id: INTEGER
  });
};

/***/ }),
/* 33 */
/***/ (function(module, exports) {

module.exports = (sequelize, DataType) => {
  const {
    STRING,
    INTEGER,
    DATE,
    BOOLEAN
  } = DataType;
  return sequelize.define('shopping_cart', {
    item_id: {
      type: INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    cart_id: STRING,
    product_id: INTEGER,
    attributes: STRING,
    quantity: INTEGER,
    buy_now: BOOLEAN,
    added_on: {
      type: DATE,
      defaultValue: new Date()
    }
  });
};

/***/ }),
/* 34 */
/***/ (function(module, exports) {

module.exports = (sequelize, DataType) => {
  const {
    INTEGER,
    STRING
  } = DataType;
  return sequelize.define('shipping', {
    shipping_id: {
      type: INTEGER,
      primaryKey: true
    },
    shipping_type: STRING,
    shipping_cost: INTEGER,
    shipping_region_id: INTEGER
  }, {
    timestamps: false,
    freezeTableName: true
  });
};

/***/ }),
/* 35 */
/***/ (function(module, exports) {

module.exports = (sequelize, DataType) => {
  const {
    INTEGER,
    STRING
  } = DataType;
  return sequelize.define('shipping_region', {
    shipping_region_id: {
      type: INTEGER,
      primaryKey: true
    },
    shipping_region: STRING
  }, {
    timestamps: false,
    freezeTableName: true
  });
};

/***/ }),
/* 36 */
/***/ (function(module, exports) {

module.exports = (sequelize, DataType) => {
  const {
    STRING,
    INTEGER,
    DECIMAL
  } = DataType;
  return sequelize.define('product_request', {
    product_id: {
      type: INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    name: STRING,
    description: STRING,
    price: DECIMAL,
    discounted_price: DECIMAL,
    color: STRING,
    size: STRING,
    quantity: STRING
  });
};

/***/ }),
/* 37 */
/***/ (function(module, exports) {

module.exports = (sequelize, DataType) => {
  const {
    INTEGER,
    STRING
  } = DataType;
  return sequelize.define('tax', {
    tax_id: {
      type: INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    percentage: INTEGER,
    tax_type: STRING
  });
};

/***/ }),
/* 38 */
/***/ (function(module, exports) {

module.exports = async (sequelize, categories, attributes, product_id, category_procedure, attribute_value_procedure) => {
  /*update product to category*/
  for (let i = 0; i < categories.length; i++) {
    await sequelize.query(category_procedure, {
      replacements: {
        inProductId: product_id,
        inCategoryId: categories[i]
      }
    });
  }
  /*update attribute value to product*/


  for (let i = 0; i < attributes.length; i++) {
    await sequelize.query(attribute_value_procedure, {
      replacements: {
        inProductId: product_id,
        inAttributeValueId: attributes[i]
      }
    });
  }
};

/***/ }),
/* 39 */
/***/ (function(module, exports, __webpack_require__) {

/** product category stored procedure*/
const {
  product_category_procedure
} = __webpack_require__(2);

module.exports = (sequelize, inCategoryId, inStartItem, inProductsPerPage, inShortProductDescriptionLength) => sequelize.query(product_category_procedure, {
  replacements: {
    inCategoryId,
    inStartItem,
    inProductsPerPage,
    inShortProductDescriptionLength
  }
});

/***/ }),
/* 40 */
/***/ (function(module, exports, __webpack_require__) {

/** product category stored procedure*/
const {
  product_department_procedure
} = __webpack_require__(2);

module.exports = (sequelize, inDepartmentId, inStartItem, inProductsPerPage, inShortProductDescriptionLength) => sequelize.query(product_department_procedure, {
  replacements: {
    inDepartmentId,
    inStartItem,
    inProductsPerPage,
    inShortProductDescriptionLength
  }
});

/***/ }),
/* 41 */
/***/ (function(module, exports, __webpack_require__) {

const {
  product_location_procedure
} = __webpack_require__(2);

module.exports = (sequelize, inProductId) => sequelize.query(product_location_procedure, {
  replacements: {
    inProductId
  }
});

/***/ }),
/* 42 */
/***/ (function(module, exports, __webpack_require__) {

/** product attribute stored procedure*/
const {
  product_review_procedure
} = __webpack_require__(2);

module.exports = (sequelize, product_id) => sequelize.query(product_review_procedure, {
  replacements: {
    inProductId: product_id
  }
});

/***/ }),
/* 43 */
/***/ (function(module, exports) {

module.exports = async (ProductAssociation, product_id) =>
/* remove products from a given Product Association model */
await ProductAssociation.destroy({
  where: {
    product_id: await ProductAssociation.findAll({
      where: {
        product_id
      },
      attributes: ["product_id"]
    }).map(item => item.product_id)
  }
});

/***/ }),
/* 44 */
/***/ (function(module, exports, __webpack_require__) {

const {
  connectToDatabase
} = __webpack_require__(1);

const Router = __webpack_require__(0);
/** Create new product request */


Router.post('/v1/admin/product/add', async (req, res) => {
  const product = req.body;

  try {
    const {
      ProductRequest
    } = await connectToDatabase();
    /*Create products with associations*/

    const product_item = await ProductRequest.create(product);
    res.status(201).send(product_item);
  } catch (err) {
    res.send(err);
  }
});
/** handle get all products request with limit of 20 items returned per page */

Router.get('/v1/admin/products', async (req, res) => {
  const {
    page
  } = req.query;

  try {
    const {
      ProductRequest
    } = await connectToDatabase();
    const getRequests = await ProductRequest.findAll({
      limit: 20,
      offset: 20 * (page - 1)
    });
    const totalRequest = await ProductRequest.count();
    res.status(200).send(getRequests, totalRequest);
  } catch (err) {
    res.send(err);
  }
});
/* handle get a product request*/

Router.get('/v1/admin/product/:product_id', async (req, res) => {
  const {
    product_id
  } = req.params;

  try {
    const {
      ProductRequest
    } = await connectToDatabase();
    const product = await ProductRequest.findOne({
      where: {
        product_id
      }
    });

    if (!product) {
      res.send({
        status: 404,
        msg: `Product with id: ${product_id} does not exist`
      });
    } else {
      res.status(200).send(product);
    }
  } catch (err) {
    res.send(err);
  }
});
module.exports = Router;

/***/ }),
/* 45 */
/***/ (function(module, exports, __webpack_require__) {

const confirmUser = __webpack_require__(46);

const login = __webpack_require__(49);

const resendCode = __webpack_require__(50);

const signUp = __webpack_require__(51);

let authRoutes = [confirmUser, login, resendCode, signUp];
module.exports = authRoutes;

/***/ }),
/* 46 */
/***/ (function(module, exports, __webpack_require__) {

/** Confirm User on cognito
* @params {string} username                   - user email address
* @params {string} confirm_code               - AWS signUp confirmation code
*/
const {
  cognitoAuthConfig
} = __webpack_require__(4);

const Router = __webpack_require__(0);

Router.post('/v1/user/confirm', async (req, res) => {
  const {
    cognitoUser
  } = cognitoAuthConfig(req.body); //Cognito confirm code method which triggers a confirmation code to complete the signUp process

  const {
    confirmCode
  } = req.body;
  await cognitoUser.confirmRegistration(confirmCode, true, (err, result) => {
    if (err) {
      res.send(err);
      return;
    }

    res.send(result);
  });
});
module.exports = Router;

/***/ }),
/* 47 */
/***/ (function(module, exports) {

module.exports = require("amazon-cognito-identity-js");

/***/ }),
/* 48 */
/***/ (function(module, exports) {

module.exports = require("node-fetch");

/***/ }),
/* 49 */
/***/ (function(module, exports, __webpack_require__) {

/** User authentication generating JWT
 * @params {string} username                   - user email address
 * @params {string} password                   - user password
 * @return {string} idToken                    - JSON web token with Bearer prefix
 */
const {
  cognitoAuthConfig
} = __webpack_require__(4);

const Router = __webpack_require__(0);

Router.post('/v1/user/login', async (req, res) => {
  //cognito function to access methods
  const {
    cognitoUser,
    authenticationDetails
  } = await cognitoAuthConfig(req.body);
  await cognitoUser.authenticateUser(authenticationDetails, {
    onSuccess(result) {
      /* Use the idToken for Logins Map when Federating User Pools with identity pools or when
       passing through an Authorization Header to an API Gateway Authorizer */
      const idToken = result.idToken.jwtToken; //Set header token with USER-KEY

      res.setHeader('USER-KEY', idToken);
      /* return the information including token as JSON*/

      res.send({
        success: true,
        idToken: `Bearer ${idToken}`
      });
    },

    onFailure(err) {
      res.send(err);
    }

  });
});
module.exports = Router;

/***/ }),
/* 50 */
/***/ (function(module, exports, __webpack_require__) {

/** Resend confirmation code to User
 * @params {string} username                   - user email address
 */
const {
  cognitoAuthConfig
} = __webpack_require__(4);

const Router = __webpack_require__(0);

Router.post('/v1/cognito/resend-code', async (req, res) => {
  const {
    cognitoUser
  } = cognitoAuthConfig(req.body); //resend confirmation code method

  cognitoUser.resendConfirmationCode((err, result) => {
    if (err) {
      res.send(err);
      return;
    }

    res.send(result);
  });
});
module.exports = Router;

/***/ }),
/* 51 */
/***/ (function(module, exports, __webpack_require__) {

/** User SignUp
 * @params {string} username                   - user email address
 * @params {string} password                   - user password
 * @params {string} firstName                  - user first name
 * @params {string} lastName                   - user last name
 */
const {
  cognitoAuthConfig,
  AmazonCognitoIdentity
} = __webpack_require__(4);

const Router = __webpack_require__(0);

const attributeList = [];
/* handle cognito user signup*/

Router.post('/v1/user/signup', async (req, res) => {
  const {
    email,
    password,
    firstName,
    lastName
  } = req.body;
  const {
    userPool
  } = cognitoAuthConfig(req.body);

  try {
    if (!email) {
      res.json({
        success: false,
        msg: 'ensure to type your email and password.'
      });
    } else {
      attributeList.push(new AmazonCognitoIdentity.CognitoUserAttribute({
        Name: 'email',
        Value: email
      }));
      attributeList.push(new AmazonCognitoIdentity.CognitoUserAttribute({
        Name: 'custom:firstName',
        Value: firstName
      }));
      attributeList.push(new AmazonCognitoIdentity.CognitoUserAttribute({
        Name: 'custom:lastName',
        Value: lastName
      }));
      let cognitoUser; //sign up method

      await userPool.signUp(email, password, attributeList, null, (err, result) => {
        if (err) {
          res.send(err);
          return;
        }

        cognitoUser = result.user;
        res.send({
          username: cognitoUser.getUsername()
        });
      });
    }
  } catch (err) {
    res.json({
      success: false,
      msg: 'error occurred trying to sign up',
      err
    });
  }
});
module.exports = Router;

/***/ }),
/* 52 */
/***/ (function(module, exports, __webpack_require__) {

const {
  connectToDatabase
} = __webpack_require__(1);

const Router = __webpack_require__(0);
/** handle get all department  */


Router.get('/v1/departments', async (req, res) => {
  try {
    const {
      Department
    } = await connectToDatabase();
    const getRequests = await Department.findAll();
    res.status(200).send(getRequests);
  } catch (err) {
    res.send(err);
  }
});
/* handle get a product request*/

Router.get('/v1/departments/:department_id', async (req, res) => {
  const {
    department_id
  } = req.params;

  try {
    const {
      Department
    } = await connectToDatabase();
    const department = await Department.findOne({
      where: {
        department_id
      }
    });

    if (!department) {
      res.send({
        status: 404,
        msg: `Department with id: ${department_id} does not exist`
      });
    } else {
      res.status(200).send(department);
    }
  } catch (err) {
    res.send(err);
  }
});
module.exports = Router;

/***/ }),
/* 53 */
/***/ (function(module, exports, __webpack_require__) {

const {
  connectToDatabase
} = __webpack_require__(1);

const Router = __webpack_require__(0);
/** get categories*/


Router.get('/v1/categories', async (req, res) => {
  try {
    const {
      Category
    } = await connectToDatabase();
    const category = await Category.findAll();

    if (!category) {
      res.send({
        status: 404,
        msg: `No category found`
      });
    } else {
      res.status(200).send(category);
    }
  } catch (err) {
    res.send(err);
  }
});
/* get category by id*/

Router.get('/v1/categories/:category_id', async (req, res) => {
  const {
    category_id
  } = req.params;

  try {
    const {
      Category
    } = await connectToDatabase();
    const category = await Category.findOne({
      where: {
        category_id
      }
    });

    if (!category) {
      res.send({
        status: 404,
        msg: `Category with id: ${category_id} does not exist`
      });
    } else {
      res.status(200).send(category);
    }
  } catch (err) {
    res.send(err);
  }
});
/** GET all department  */

Router.get('/v1/categories/inProduct/:product_id', async (req, res) => {
  const {
    product_id
  } = req.params;

  try {
    const {
      ProductCategory,
      Category
    } = await connectToDatabase();
    const categoryID = await ProductCategory.findOne({
      limit: 1,
      where: {
        product_id
      }
    }); //   .then(async (data) => {
    //   await Category.findOne({
    //     limit: 1,
    //     where: {category_id: data.category_id}
    //   });
    // });
    // console.log(categoryID, 'Category ID')

    const category = await Category.findAll({
      limit: 1,
      where: {
        category_id: categoryID.category_id
      },
      attributes: {
        exclude: ['description']
      }
    });
    res.status(200).send(category);
  } catch (err) {
    res.send(err);
  }
});
/* GET Categories of a Department */

Router.get('/v1/categories/inDepartment/:department_id', async (req, res) => {
  const {
    department_id
  } = req.params;

  try {
    const {
      Category
    } = await connectToDatabase();
    const category = await Category.findAll({
      where: {
        department_id
      }
    });

    if (!category) {
      res.send({
        status: 404,
        msg: `Category with id: ${department_id} does not exist`
      });
    } else {
      res.status(200).send(category);
    }
  } catch (err) {
    res.send(err);
  }
});
module.exports = Router;

/***/ }),
/* 54 */
/***/ (function(module, exports, __webpack_require__) {

/** T-shirt shop product API
 * @params {string} attributes                  - Product attribute
 * @params {number} attribute_id                - Attribute ID
 * @params {number} product_id                  - Product ID
*/
const {
  connectToDatabase,
  sequelize
} = __webpack_require__(1);

const Router = __webpack_require__(0);

const product_attribute_procedure = __webpack_require__(55); // response when a query returns an empty body


const notFound = (res, type, id) => res.send({
  status: 404,
  msg: `${type} with id: ${id} does not exist`
});
/** GET all attributes */


Router.get('/v1/attributes', async (req, res) => {
  try {
    const {
      Attribute
    } = await connectToDatabase();
    const attributes = await Attribute.findAll();
    res.status(200).send(attributes);
  } catch (err) {
    res.status(500).send(err);
  }
});
/* GET attribute using attribute id*/

Router.get('/v1/attributes/:attribute_id', async (req, res) => {
  const {
    attribute_id
  } = req.params;

  try {
    const {
      Attribute
    } = await connectToDatabase();
    const attribute = await Attribute.findOne({
      where: {
        attribute_id
      }
    });
    if (!attribute) return await notFound(res, 'attribute', attribute_id);
    res.status(200).send(attribute);
  } catch (err) {
    res.send(err);
  }
});
/* get a product using product id*/

Router.get('/v1/attributes/values/:attribute_id', async (req, res) => {
  const {
    attribute_id
  } = req.params;

  try {
    const {
      AttributeValue
    } = await connectToDatabase();
    const attribute_values = await AttributeValue.findAll({
      where: {
        attribute_id
      },
      attributes: {
        exclude: ['attribute_id']
      }
    });
    res.status(200).send(attribute_values);
  } catch (err) {
    res.send(err);
  }
});
/* GEt all Attributes with Product ID */

Router.get('/v1/attributes/inProduct/:product_id', async (req, res) => {
  const {
    product_id
  } = req.params;

  try {
    await connectToDatabase();
    const attribute_values = await product_attribute_procedure(sequelize, product_id);
    if (!attribute_values) return await notFound(res, 'attribute', product_id);
    res.status(200).send(attribute_values);
  } catch (err) {
    res.send(err);
  }
});
module.exports = Router;

/***/ }),
/* 55 */
/***/ (function(module, exports, __webpack_require__) {

/** product attribute stored procedure*/
const {
  product_attributes_procedure
} = __webpack_require__(2);

module.exports = (sequelize, product_id) => sequelize.query(product_attributes_procedure, {
  replacements: {
    inProductId: product_id
  }
});

/***/ }),
/* 56 */
/***/ (function(module, exports, __webpack_require__) {

const {
  connectToDatabase
} = __webpack_require__(1);

const Router = __webpack_require__(0);

const verifyToken = __webpack_require__(3).verify_token;

const secureRoute = __webpack_require__(3).secureRoute;
/** GET all orders*/


Router.get('/v1/orders/inCustomer/:inCustomer', verifyToken, async (req, res) => {
  const {
    inCustomer
  } = req.params;

  try {
    const buildRoute = secureRoute(req, res);
    return buildRoute(async () => {
      const {
        Order
      } = await connectToDatabase();
      const orders = await Order.findAll({
        where: {
          customer_id: inCustomer
        }
      });

      if (!orders) {
        res.send({
          status: 404,
          msg: `No order found`
        });
      } else {
        res.status(200).send(orders);
      }
    });
  } catch (err) {
    res.send(err);
  }
});
/* get category by id*/

Router.get('/v1/orders/:order_id', verifyToken, async (req, res) => {
  const {
    order_id
  } = req.params;

  try {
    const buildRoute = secureRoute(req, res);
    return buildRoute(async () => {
      const {
        Order
      } = await connectToDatabase();
      const order = await Order.findOne({
        where: {
          order_id
        }
      });

      if (!order) {
        res.send({
          status: 404,
          msg: `Order with id: ${order_id} does not exist`
        });
      } else {
        res.status(200).send(order);
      }
    });
  } catch (err) {
    res.send(err);
  }
});
/** POST create an order*/

Router.post('/v1/orders', verifyToken, async (req, res) => {
  const {
    Order
  } = await connectToDatabase();
  const {
    orders,
    shipping_id,
    tax_id
  } = req.body;

  try {
    const buildRoute = secureRoute(req, res);
    await buildRoute(async () => {
      const createOrder = await Promise.all(orders.map(order => Order.create({
        total_amount: order.salePrice * order.quantity,
        status: 1,
        customer_id: order.customer_id,
        reference: order.reference,
        shipping_id,
        tax_id
      })));
      res.status(201).send({
        success: true,
        createOrder
      });
    });
  } catch (err) {
    res.send(err);
  }
});
/* DELETE multiple orders */

Router.delete('/v1/orders', verifyToken, async (req, res) => {
  let {
    order_id
  } = req.query;
  order_id = JSON.parse(order_id);

  try {
    const {
      Order
    } = await connectToDatabase();
    const buildRoute = secureRoute(req, res);
    return await buildRoute(async () => {
      const deleteOrders = await Order.destroy({
        where: {
          order_id
        }
      });
      res.send({
        deleteOrders
      });
    });
  } catch (err) {
    res.send(err);
  }
});
module.exports = Router;

/***/ }),
/* 57 */
/***/ (function(module, exports, __webpack_require__) {

const {
  connectToDatabase
} = __webpack_require__(1);

const Router = __webpack_require__(0);
/** GET all Shipping regions  */


Router.get('/v1/shipping/regions', async (req, res) => {
  try {
    const {
      ShippingRegion
    } = await connectToDatabase();
    const shippingRegions = await ShippingRegion.findAll();
    res.status(200).send(shippingRegions);
  } catch (err) {
    res.send(err);
  }
});
/* GET all shipping with shipping_region_id ID*/

Router.get('/v1/shipping/regions/:shipping_regions_id', async (req, res) => {
  const {
    shipping_regions_id
  } = req.params;

  try {
    const {
      Shipping
    } = await connectToDatabase();
    const shippingRegion = await Shipping.findAll({
      where: {
        shipping_regions_id
      }
    });

    if (!shippingRegion) {
      res.send({
        status: 404,
        msg: `Shipping with id: ${shipping_regions_id} does not exist`
      });
    } else {
      res.status(200).send(shippingRegion);
    }
  } catch (err) {
    res.send(err);
  }
});
module.exports = Router;

/***/ }),
/* 58 */
/***/ (function(module, exports, __webpack_require__) {

/** T-shirt shop product API Shopping Cart end-points
 * @params {string} shopping_cart                  - Shopping Cart
 * @params {number} cart_id                        - Cart ID
 * @params {number} item_id                        - Item ID
 * @params {number} inCartId                        - Cart ID
 * @params {number} inProductId                     - Product ID
 * @params {number} inAttributes                    - Attribute ID
 */
const {
  sequelize
} = __webpack_require__(1);

const randomstring = __webpack_require__(59);

const Router = __webpack_require__(0);

const {
  addToCart,
  cartList,
  emptyCart,
  moveToCart,
  cartTotal,
  saveToCart,
  getFromCart,
  updateCart,
  removeFromCart
} = __webpack_require__(60); // response when a query returns an empty body


const notFound = (res, type, id) => res.send({
  status: 404,
  msg: `${type} with id: ${id} does not exist or was not found`
}); // Success response


const success = (res, item, code) => res.status(code).send({
  success: true,
  item
});
/** GET Generate the unique Cart ID*/


Router.get('/v1/shoppingcart/generateUniqueId', async (req, res) => {
  try {
    const uniqueId = await randomstring.generate(12);
    res.status(200).send({
      cart_id: uniqueId
    });
  } catch (err) {
    res.send(err);
  }
});
/**
 * POST add products to shopping cart using cart ID
 */

Router.post('/v1/shoppingcart/add', async (req, res) => {
  const {
    inCartId,
    inProductId,
    inAttributes
  } = req.body;

  try {
    const shoppingCart = await addToCart(sequelize, inCartId, inProductId, inAttributes);
    await success(res, shoppingCart, 201);
  } catch (err) {
    res.status(500).send(err);
  }
});
/** GET list of products in shopping cart */

Router.get('/v1/shoppingcart/:cart_id', async (req, res) => {
  const {
    cart_id
  } = req.params;

  try {
    const shoppingCart = await cartList(sequelize, cart_id);
    if (!cart_id) return notFound(res, 'Cart', cart_id);
    await success(res, shoppingCart, 202);
  } catch (err) {
    res.status(500).send(err);
  }
});
/* PUT update the product quantity in shopping cart*/

Router.put('/v1/shoppingcart/update/:item_id', async (req, res) => {
  const {
    item_id
  } = req.params;
  const {
    inQuantity
  } = req.body;

  try {
    const shoppingCart = await updateCart(sequelize, item_id, inQuantity); // if(!shoppingCart) return notFound(res, 'Item', item_id);

    await success(res, shoppingCart, 202);
  } catch (err) {
    res.send(err);
  }
});
/** DELETE Empty cart*/

Router.delete('/v1/shoppingcart/empty/:cart_id', async (req, res) => {
  const {
    cart_id
  } = req.params;

  try {
    const shoppingCart = await emptyCart(sequelize, cart_id);
    if (!shoppingCart) return notFound(res, 'Cart', cart_id);
    await success(res, shoppingCart, 204);
  } catch (err) {
    res.send(err);
  }
});
/** GET Move a product to cart */

Router.get('/v1/shoppingcart/moveToCart/:item_id', async (req, res) => {
  const {
    item_id
  } = req.params;

  try {
    const shoppingCart = await moveToCart(sequelize, item_id); // if(!shoppingCart) return notFound(res, 'Cart', item_id);

    await success(res, shoppingCart, 200);
  } catch (err) {
    res.send(err);
  }
});
/* GET return total amount from cart*/

Router.get('/v1/shoppingcart/totalAmount/:cart_id', async (req, res) => {
  const {
    cart_id
  } = req.params;

  try {
    const totalAmount = await cartTotal(sequelize, cart_id);
    await success(res, totalAmount, 200);
  } catch (err) {
    res.send(err);
  }
});
/** GET Save a product for latter*/

Router.get('/v1/shoppingcart/saveForLater/:item_id', async (req, res) => {
  const {
    item_id
  } = req.params;

  try {
    const shoppingCart = await saveToCart(sequelize, item_id);
    await success(res, shoppingCart, 200);
  } catch (err) {
    res.send(err);
  }
});
/* GET Product saved for later */

Router.get('/v1/shoppingcart/getSavedItem/:cart_id', async (req, res) => {
  const {
    cart_id
  } = req.params;

  try {
    const getSavedItem = await getFromCart(sequelize, cart_id);
    if (!getSavedItem) return notFound(res, 'Cart', cart_id);
    await success(res, getSavedItem, 200);
  } catch (err) {
    res.send(err);
  }
});
/** DELETE Remove a product from cart */

Router.delete('/v1/shoppingcart/removeProduct/:item_id', async (req, res) => {
  const {
    item_id
  } = req.params;

  try {
    const shoppingCart = await removeFromCart(sequelize, item_id);
    if (!shoppingCart) return notFound(res, 'Cart', item_id);
    await success(res, shoppingCart, 204);
  } catch (err) {
    res.send(err);
  }
});
module.exports = Router;

/***/ }),
/* 59 */
/***/ (function(module, exports) {

module.exports = require("randomstring");

/***/ }),
/* 60 */
/***/ (function(module, exports, __webpack_require__) {

/** Shopping cart procedures */
const {
  shopping_cart_add_procedure,
  shopping_cart_list_procedure,
  shopping_cart_empty_procedure,
  shopping_cart_move_procedure,
  shopping_cart_total_procedure,
  shopping_cart_get_procedure,
  shopping_cart_remove_procedure,
  shopping_cart_save_procedure,
  shopping_cart_update_procedure
} = __webpack_require__(2);

module.exports.addToCart = (sequelize, inCartId, inProductId, inAttributes) => sequelize.query(shopping_cart_add_procedure, {
  replacements: {
    inCartId,
    inProductId,
    inAttributes
  }
});

module.exports.cartList = (sequelize, inCartId) => sequelize.query(shopping_cart_list_procedure, {
  replacements: {
    inCartId
  }
});

module.exports.emptyCart = (sequelize, inCartId) => sequelize.query(shopping_cart_empty_procedure, {
  replacements: {
    inCartId
  }
});

module.exports.moveToCart = (sequelize, inItemId) => sequelize.query(shopping_cart_move_procedure, {
  replacements: {
    inItemId
  }
});

module.exports.cartTotal = (sequelize, inCartId) => sequelize.query(shopping_cart_total_procedure, {
  replacements: {
    inCartId
  }
});

module.exports.saveToCart = (sequelize, inItemId) => sequelize.query(shopping_cart_save_procedure, {
  replacements: {
    inItemId
  }
});

module.exports.getFromCart = (sequelize, inCartId) => sequelize.query(shopping_cart_get_procedure, {
  replacements: {
    inCartId
  }
});

module.exports.updateCart = (sequelize, inItemId, inQuantity) => sequelize.query(shopping_cart_update_procedure, {
  replacements: {
    inItemId,
    inQuantity
  }
});

module.exports.removeFromCart = (sequelize, inItemId) => sequelize.query(shopping_cart_remove_procedure, {
  replacements: {
    inItemId
  }
});

/***/ }),
/* 61 */
/***/ (function(module, exports, __webpack_require__) {

const {
  connectToDatabase
} = __webpack_require__(1);

const Router = __webpack_require__(0);
/** handle get all tax  */


Router.get('/v1/tax', async (req, res) => {
  try {
    const {
      Tax
    } = await connectToDatabase();
    const taxes = await Tax.findAll();
    res.status(200).send(taxes);
  } catch (err) {
    res.send(err);
  }
});
/* GET tax by ID*/

Router.get('/v1/tax/:tax_id', async (req, res) => {
  const {
    tax_id
  } = req.params;

  try {
    const {
      Tax
    } = await connectToDatabase();
    const tax = await Tax.findOne({
      where: {
        tax_id
      }
    });

    if (!tax) {
      res.send({
        status: 404,
        msg: `Tax with id: ${tax_id} does not exist`
      });
    } else {
      res.status(200).send(tax);
    }
  } catch (err) {
    res.send(err);
  }
});
module.exports = Router;

/***/ }),
/* 62 */
/***/ (function(module, exports, __webpack_require__) {

/** T-shirt shop product API Customer end-points
 * @params {string} shopping_cart                  - Shopping Cart
 * @params {number} cart_id                        - Cart ID
 * @params {number} item_id                        - Item ID
 * @params {number} inCartId                        - Cart ID
 * @params {number} inProductId                     - Product ID
 * @params {number} inAttributes                    - Attribute ID
 */
const {
  connectToDatabase,
  sequelize
} = __webpack_require__(1);

const Router = __webpack_require__(0);

const bcrypt = __webpack_require__(63);

const jwt = __webpack_require__(7);

const _ = __webpack_require__(8);

const {
  addCustomer,
  getCustomer,
  getCustomerList,
  getShippingRegion,
  updateAccount,
  updateAddress,
  updateCreditCard
} = __webpack_require__(64);

const login = __webpack_require__(65);

const verifyToken = __webpack_require__(3).verify_token;

const secureRoute = __webpack_require__(3).secureRoute; // const midWare = require('../../helpers/redis_cache');
// const redisMiddleware = require('../../helpers/app_cache').redisMiddleware;


const salt = bcrypt.genSaltSync(8); // response when a query returns an empty body

const notFound = (res, type, id) => res.send({
  status: 404,
  msg: `${type} with id: ${id} does not exist or was not found`
}); // Success response


const success = (res, item, code) => res.status(code).send({
  success: true,
  item
});
/** POST Create a new customer */


Router.post('/v1/customer', async (req, res) => {
  const {
    inName,
    inEmail,
    inPassword
  } = req.body;
  const {
    Customer
  } = await connectToDatabase();

  try {
    const customer = await addCustomer(sequelize, inName, inEmail, bcrypt.hashSync(inPassword, salt));
    if (customer) await login(Customer, res, inEmail, inPassword, bcrypt, jwt);
  } catch (err) {
    if (err.errors[0].message === "idx_customer_email must be unique") return res.json({
      status: 401,
      success: false,
      msg: 'User with the email already exist'
    });
    res.send(err);
  }
});
/** GET Return a customer */

Router.get('/v1/customer', verifyToken, async (req, res) => {
  const {
    inCustomerId
  } = req.query;

  try {
    const buildRoute = secureRoute(req, res);
    return buildRoute(async () => {
      let customer = await getCustomer(sequelize, inCustomerId);
      customer = _.omit(customer[0], 'password');
      await success(res, customer, 200);
    });
  } catch (err) {
    res.send(err);
  }
});
/** GET Return all customers */

Router.get('/v1/customers', async (req, res) => {
  try {
    const customers = await getCustomerList(sequelize);
    await success(res, customers, 200);
  } catch (err) {
    res.send(err);
  }
});
/** POST customer logs in */

Router.post('/v1/customer/login', async (req, res) => {
  const {
    Customer
  } = await connectToDatabase();
  const {
    email,
    password
  } = req.body;

  try {
    await login(Customer, res, email, password, bcrypt, jwt);
  } catch (err) {
    res.send(err);
  }
});
/** GET Return shipping region */

Router.get('/v1/customer/shippingRegion', async (req, res) => {
  try {
    const customers = await getShippingRegion(sequelize);
    success(res, customers, 200);
  } catch (err) {
    res.send(err);
  }
});
/** PUT Update customer address */

Router.put('/v1/customer/address', verifyToken, async (req, res) => {
  const {
    inCustomerId,
    inAddress1,
    inAddress2,
    inCity,
    inRegion,
    inPostalCode,
    inCountry,
    inShippingRegionId
  } = req.body;

  try {
    const buildRoute = secureRoute(req, res);
    return buildRoute(async () => {
      const customer = await updateAddress(sequelize, inCustomerId, inAddress1, inAddress2, inCity, inRegion, inPostalCode, inCountry, inShippingRegionId);
      await success(res, customer, 202);
    });
  } catch (err) {
    res.send(err);
  }
});
/** PUT Update customer address */

Router.put('/v1/customer', verifyToken, async (req, res) => {
  const {
    inCustomerId,
    inName,
    inEmail,
    inPassword,
    inDayPhone,
    inEvePhone,
    inMobPhone
  } = req.body;
  const password = await bcrypt.hashSync(inPassword, salt);

  try {
    const buildRoute = secureRoute(req, res);
    return buildRoute(async () => {
      const customer = await updateAccount(sequelize, inCustomerId, inName, inEmail, password, inDayPhone, inEvePhone, inMobPhone);
      await success(res, customer, 202);
    });
  } catch (err) {
    res.send(err);
  }
});
/** PUT Update customer address */

Router.put('/v1/customer/creditCard', verifyToken, async (req, res) => {
  const {
    inCustomerId,
    inCreditCard
  } = req.body;

  try {
    const buildRoute = secureRoute(req, res);
    return buildRoute(async () => {
      const customer = await updateCreditCard(sequelize, inCustomerId, inCreditCard);
      await success(res, customer, 202);
    });
  } catch (err) {
    res.send(err);
  }
});
module.exports = Router;

/***/ }),
/* 63 */
/***/ (function(module, exports) {

module.exports = require("bcryptjs");

/***/ }),
/* 64 */
/***/ (function(module, exports, __webpack_require__) {

/** Shopping cart procedures */
const {
  customer_add_procedure,
  customer_get_procedure,
  customer_get_list_procedure,
  customer_get_shipping_regions_procedure,
  customer_update_account_procedure,
  customer_update_address_procedure,
  customer_update_credit_card_procedure
} = __webpack_require__(2);

module.exports.addCustomer = (sequelize, inName, inEmail, inPassword) => sequelize.query(customer_add_procedure, {
  replacements: {
    inName,
    inEmail,
    inPassword
  }
});

module.exports.getCustomer = (sequelize, inCustomerId) => sequelize.query(customer_get_procedure, {
  replacements: {
    inCustomerId
  }
});

module.exports.getCustomerList = sequelize => sequelize.query(customer_get_list_procedure);

module.exports.getShippingRegion = sequelize => sequelize.query(customer_get_shipping_regions_procedure);

module.exports.updateAccount = (sequelize, inCustomerId, inName, inEmail, inPassword, inDayPhone, inEvePhone, inMobPhone) => sequelize.query(customer_update_account_procedure, {
  replacements: {
    inCustomerId,
    inName,
    inEmail,
    inPassword,
    inDayPhone,
    inEvePhone,
    inMobPhone
  }
});

module.exports.updateAddress = (sequelize, inCustomerId, inAddress1, inAddress2, inCity, inRegion, inPostalCode, inCountry, inShippingRegionId) => sequelize.query(customer_update_address_procedure, {
  replacements: {
    inCustomerId,
    inAddress2,
    inCity,
    inRegion,
    inPostalCode,
    inCountry,
    inShippingRegionId
  }
});

module.exports.updateCreditCard = (sequelize, inCustomerId, inCreditCard) => sequelize.query(customer_update_credit_card_procedure, {
  replacements: {
    inCustomerId,
    inCreditCard
  }
});

/***/ }),
/* 65 */
/***/ (function(module, exports, __webpack_require__) {

const _ = __webpack_require__(8);

module.exports = async (Customer, res, email, password, bcrypt, jwt) => await Customer.findOne({
  where: {
    email
  }
}).then(async user => {
  if (!user) {
    res.json({
      status: 401,
      success: false,
      msg: 'Authentication failed. User not found.'
    });
  }

  if (user) {
    await bcrypt.compare(password, user.password, (err, isMatch) => {
      if (isMatch && !err) {
        user = _.omit(user.toJSON(), 'password'); // if user is found and password is right create a token

        const token = jwt.sign(user, process.env.privateKey, {
          expiresIn: '1440m'
        });
        res.setHeader('USER-KEY', 'Bearer ' + token); // return the information including token as JSON

        res.status(201).json({
          success: true,
          customer: {
            schema: user,
            accessToken: `Bearer ${token}`,
            expires_in: '24h'
          }
        });
      } else {
        res.json({
          status: 401,
          success: false,
          msg: 'Authentication failed. Wrong password.'
        });
      }
    });
  }
});

/***/ })
/******/ ])));
//# sourceMappingURL=server.js.map